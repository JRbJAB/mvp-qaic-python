# WEBAPP_ARCHITECTURE_CDC

Dossier cible pour le CDC Architecture WebApp MVP QAIC.

CURRENT recommandé :
- CDC_MVP_QAIC_WEBAPP_ARCHITECTURE_QAIC_LIAISON_v0_1_2.md
- CDC_MVP_QAIC_WEBAPP_ARCHITECTURE_SCHEMA_PRO_v0_1_2.png
- CDC_MVP_QAIC_WEBAPP_ARCHITECTURE_SCHEMA_PRO_v0_1_2.svg
- CDC_MVP_QAIC_WEBAPP_ARCHITECTURE_VERIFY_v0_1_2.json

À faire plus tard :
- fusion avec le CDC QAIC quand QAIC aura figé ses contrats de passerelle.
